using Autofac;
using Autofac.Extensions.DependencyInjection;
using ServiceContracts;
using Services;
var builder = WebApplication.CreateBuilder(args);
//builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory()); //telling VS to use Autofac instead of preimplemented IoC
builder.Services.AddControllersWithViews();

//Inversion of Control (IoC). Creates an object that implements the interface which the developers use to communicate what they do and need without depending one each other.
//if you call the interface in a controller, this service's object will be created and will implement that interface you called in main project by itself.

/*
builder.Services.Add(   //classic way of making an IoC, but there's better
    new ServiceDescriptor(
    typeof(ICitiesService),
    typeof(CitiesService),
    ServiceLifetime.Transient)
    );
*/


//builder.Host.ConfigureContainer<ContainerBuilder>(
    /*
    containerBuilder =>
    {
        containerBuilder.RegisterType<CitiesService>().As<ICitiesService>().InstancePerDependency(); // equivalent of builder.Services.AddTransient<ICitiesService, CitiesService>();
    },
    */
    /*
    containerBuilder=>
    {
        containerBuilder.RegisterType<CitiesService>().As<ICitiesService>().InstancePerLifetimeScope(); // equivalent of builder.Services.AddScoped<ICitiesService,CitiesService>();
    }
    */
    /*
    containerBuilder =>
    {
        containerBuilder.RegisterType<CitiesService>().As<ICitiesService>().SingleInstance();// equivalent of builder.Services.AddSingleton<ICitiesService, CitiesService>()
    }
    */
   // );
builder.Services.AddTransient<ICitiesService, CitiesService>(); //same as the commented code above, but faster to write
//builder.Services.AddScoped<ICitiesService,CitiesService>();
//builder.Services.AddSingleton<ICitiesService, CitiesService>(); //if you do this multiple times, only the last one is taken into account, so it's better to comment what you don't need.

//Service lifetime indicates when a new object should be created 

//Transient => per injection (a new object is created every time a service is injected, either in constructors or using [FromService]
//Scoped =>per scope (browser request) if both client-server and server-client responses end, new objects will be created on the next request
//Singleton => for entire application lifetime
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.MapControllers();

//services trebuie facute primele (inainte de controllere, adica MVC pattern)

app.Run();
