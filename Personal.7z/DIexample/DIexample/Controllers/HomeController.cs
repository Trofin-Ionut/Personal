﻿using Microsoft.AspNetCore.Mvc;
using ServiceContracts;
namespace DIexample.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICitiesService _citiesService1; //toate campurile private se scriu cu underscore (naming convention)
        private readonly ICitiesService _citiesService2;
        private readonly ICitiesService _citiesService3;
        private readonly IServiceScopeFactory _serviceScopeFactory; //child scope. A object is created by IoC if is required as a parameter
        //private readonly ILifetimeService _autofacServiceScopeFactory;
        /*
        //Direct Dependency example
        public HomeController()
        {
            //Toate serviciile se instantiaza in constructorul controllerului.
            _citiesService1 = null;
        }
        */
        public HomeController(ICitiesService citiesService1, ICitiesService citiesService2, ICitiesService citiesService3, IServiceScopeFactory serviceScopeFactory)    //IoC will pass the parameter as an object here. IoC => ServiceDescriptor creates the object required for the interface
        {
            //These will have a new Guid everytime this method is called (Transient => a new object on every injection) => these 3 objects will have different Guid
            //Scoped => new object per browser request => these 3 objects will be identical (same Guid) and they will share the same new object on the next browser (HTTP) request
            //Singleton => new object is created only on first request of the application => these 3 objects will share the same object and the next new object will happen when the application is restarted ONLY
            _citiesService1 = citiesService1;
            _citiesService2 = citiesService2;
            _citiesService3 = citiesService3;
            _serviceScopeFactory = serviceScopeFactory;
        }

        [Route("/")]
        public IActionResult Index([FromServices] ICitiesService citiesService)  // [FromService] instructs the IoC to pass the object here aswell.
        {
            List<string> cities=_citiesService1.GetCountries(); //serviciile pot avea date de peste tot (date din mana, din baze de date, etc).
            ViewBag.CitiesService1InstanceId = _citiesService1.ServiceInstanceId; //Note, ViewBag can have any named object (like CitiesService1InstanceId. It's a random name, not a predefined class from ViewBag)
            ViewBag.CitiesService2InstanceId = _citiesService2.ServiceInstanceId;
            ViewBag.CitiesService3InstanceId = _citiesService3.ServiceInstanceId;

            /*
             using (ILifetimeScope scope= _autofacServiceScopeFactory.BeginLifetimeScope())
            {
            ICitiesService citiesService= scope.Resolve<ICitiesService>();
            }
             */

            using (IServiceScope scope = _serviceScopeFactory.CreateScope()) 
            {//everything created here ends at the end of using's end bracket

                //inject CitiesService
                ICitiesService scopedCitiesService=scope.ServiceProvider.GetRequiredService<ICitiesService>(); //you inject it as a part of this scope (using determines the scope's lifetime)

                //DB work
                ViewBag.ScopedInstanceCitiesService = scopedCitiesService.ServiceInstanceId;

            } // => end of scope(child scope). It calls CitiesService.Dispose by default (if you use a object of CitiesService)
            return View(cities);
        }
    }
}
