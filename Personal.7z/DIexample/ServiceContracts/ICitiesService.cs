﻿namespace ServiceContracts
{
    public interface ICitiesService
    {
        Guid ServiceInstanceId { get; }
        List<string> GetCountries(); //here developer a asks what methods the developer b should implement. they communicate through an interface
    }
}