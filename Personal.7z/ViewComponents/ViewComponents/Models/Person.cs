﻿namespace ViewComponents.Models
{
    public class Person
    {
        public string? Name { get; set; }
        public string? Job { get; set; }
        public Person(string? name, string? job) 
        {
            Name= name;
            Job=job;
        }
    }
}
