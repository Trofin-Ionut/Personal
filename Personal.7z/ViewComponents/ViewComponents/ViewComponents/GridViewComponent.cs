﻿using Microsoft.AspNetCore.Mvc;
using ViewComponents.Models;
namespace ViewComponents.ViewComponents
{
    [ViewComponent]
    public class GridViewComponent : ViewComponent
    {
        //this can be used for business logic (databases) too
        public async Task<IViewComponentResult> InvokeAsync(PersonGridModel grid) //this parameter is used so you can pass it to the component's view
        {
            
            return View(grid);
            //ViewData["Grid"] = model;
           // return View(model); //invokes a partial view at ~/Views/Shared/Components/Grid/Default.cshtml  (default is preferred)
            //return View("AnyName"); //makes the compiler look for this view named like that in the Grid's folder
        }
    }
}
