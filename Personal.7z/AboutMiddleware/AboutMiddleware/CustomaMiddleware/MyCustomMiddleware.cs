﻿using System.Runtime.CompilerServices;

namespace AboutMiddleware.CustomaMiddleware
{
    public class MyCustomMiddleware : IMiddleware
    {
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            await context.Response.WriteAsync("My brand new custom middleware.");
            await next(context);// this passes the priority to the nearest middleware below where is called
            await context.Response.WriteAsync("The end of the custom middleware."); // this is executed imediately after the middleware chaining ended, this apply
            //for all the content left from all middlewares's content below the await next(content) line of each middleware. The order is still maintained.
        }
    }

    public static class CustomMiddlewareExtension
    {
        public static IApplicationBuilder UseCustomExtension (this IApplicationBuilder app)
        {
            return app.UseMiddleware<MyCustomMiddleware>();
        }
    }
}
