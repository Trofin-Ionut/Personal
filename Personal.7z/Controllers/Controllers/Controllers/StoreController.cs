﻿using Microsoft.AspNetCore.Mvc;

namespace Controllers.Controllers
{
    public class StoreController : Controller
    {
        [Route("store/books/{id?}")]
        public IActionResult Books()
        {
            return Content("<h1>Virtual Bookstore</h1>","text/html");
        }
    }
}
