﻿using Controllers.Models;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace Controllers.Controllers
{
    [Controller]          //it's best to use both the [Controller] and the "Controller" sufix for class name. (but you can use only the sufix if you wish)
    public class HomeController : Controller
    {
        [Route("hi")]
        public string method()
        {
            return "Hello\n";
        }
        [Route("/")]
        [Route("cool")]  //=> multiple routes can exist for the same method; 
        [Route("/test2/{mobile:regex(^\\d{{10}}$)}")]  //all functionalities of endpoints work aswell  the {{10}} = {10} for regex =>exact nr of numeric characters needed for page to work
        public string test1()
        {
            return "I am cool\n ";
        }
        [Route("contResult")]
        public ContentResult contRes()
        {
            //return new ContentResult {Content="I am a content result\n",ContentType="text/plain"};
            return Content("I am a content result\n", "text/plain");
        }
        [Route("Person")]
        public JsonResult AboutPerson()       //Json= Javascript object notation (format that's recognised almost all programming languages. Good to communicate them through HTTP requests
        {
            Person person = new Person() { Id = Guid.NewGuid(), FirstName = "James", LastName = "Benchpress", Age = 25 };
            // return new JsonResult(person);
            return Json(person);
        }
        [Route("DownloadFile")]
        public VirtualFileResult DownloadFile()  //used for when your item is present in the wwwroot folder
        {
            return new VirtualFileResult("/Contract .pdf", "application/pdf"); //for some reason, it can't find the file for me
        }
        [Route("DownloadAbsolute")]
        public PhysicalFileResult PhysicalFile()  //used for files outside the project folders
        {
            //return new PhysicalFileResult(@"C:\\Users\\User\\Desktop\\Camin Protos\\Contract .pdf", "application/pdf");
            return PhysicalFile(@"C:\\Users\\User\\Desktop\\Camin Protos\\Contract .pdf", "application/pdf");
        }
        [Route("DownloadFromBits")]
        public FileContentResult FileContent()
        {
            byte[] bytes = System.IO.File.ReadAllBytes(@"C:\\Users\\User\\Desktop\\Camin Protos\\Contract .pdf");
            return File(bytes, "application/pdf"); //you can use File for 2 (first and third ) methods and you can use IActionResult as return datatype for all 3
        }
        [Route("Bookstore/{bookId?}/{isLoggedIn?}")]
        public IActionResult Action([FromRoute]int? bookId, [FromQuery] bool isLoggedIn,[FromRoute] Book book)  //route => route params => /{ p }/... 
        {                                                                                 //query params=> Bookstore?bookId=10&isLoggedIn=true
            if (!bookId.HasValue)//!Request.Query.ContainsKey("bookId"))                //vezi ca la clase [From..] ia atribute pt toate campurile doar din acel nivel ales
            {
               //return Content("The request has no book id in it");
               return BadRequest("The request has no book id in it\n");
            }
           /* if (string.IsNullOrEmpty(Request.Query["bookId"]))
            {
                //return Content("Book id can't be null or empty");
                return BadRequest("Book id can't be null or empty\n");
            }*/
            if (/*Convert.ToInt32(Request.Query["bookId"])*/ bookId > 1000 || bookId < 1)
            {
               // return Content("Book id not in range");
               return NotFound("Book id not in range\n");
            }
            if (!isLoggedIn)
            {
                return Unauthorized("User is not logged in\n");
                //you can use aswell: return StatusCode(401); , but has no response body. 
            }
           // int bookId = Convert.ToInt32(Request.Query["bookId"]);

            //  return File("Contract .pdf", "application/pdf");

            //return new RedirectToActionResult("Books","Store",new { },true); //actionName= method name ,ControllerName= from which controller you want to look for that methodName, new{} is optional for route parameters
            //return RedirectToAction("Books", "Store",new { id= bookId});
            // return new LocalRedirectResult($"store/books/{bookId}");
           // return LocalRedirect($"store/books/{bookId}",true);
            return RedirectPermanent($"store/books/{bookId}");
        }
    }
}
