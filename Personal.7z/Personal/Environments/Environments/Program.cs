var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.MapControllers();

//To change the environment, you click on the Properties file and look into launchSettings.json.
//On profiles, you can write Development ,Staging or Production

if(app.Environment.IsDevelopment()) //mai ai .IsStaging() , .IsProduction(), IsEnvironment(string environmentName) , in case you have a custom environment
{
    //they all have their own dedicated exception page
    app.UseDeveloperExceptionPage();  //friendly for developers, unfriendly for end users ,productionExceptionPage is vice-versa.
}

app.Run();
