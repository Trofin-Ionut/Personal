﻿namespace Controllers.Models
{
    public class Book
    {
        //[FromRoute] => poti face asta daca nu vrei sa scrii inaintea obiectului asta...
         public int? Id { get; set; }
        public string? Author { get; set; }
        public override string ToString()
        {
            return $"Book's id: {Id} ,written by {Author}";
        }
    }
}
