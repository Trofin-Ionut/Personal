﻿using ServiceContracts;
namespace Services
{
    //toate clasele care au rol de "servicii" trebuie sa aiba sufixul Service (naming convention)
    //public class CitiesService
    public class CitiesService:ICitiesService,IDisposable //Dependency Inversion principle, gen un dev vrea sa folosesti niste metode in toate serviciile tale, iar nimica din ce are el sau tu nu depinde una de alta
    {
        //nota. Proiectul principal nu trebuie sa depinda direct de servicii, ci comunica prin interfata cu ele. (DIP). Poti sa ai referinte direct catre proiectul cu servicii, dar nu-l folosi direct.
        private List<string> _cities;
        private Guid _serviceInstanceId;
        public Guid ServiceInstanceId
        {
            get
            {
                return _serviceInstanceId;
            }
        }
        public CitiesService() 
        {
            _serviceInstanceId = Guid.NewGuid();
            _cities = new List<string>() { "Paris","London","Dubai","Instambul","Romania","Rome"};
        }
        public List<string> GetCountries() => _cities;

        public void Dispose()
        {
            //To do: something
        }
    }
}