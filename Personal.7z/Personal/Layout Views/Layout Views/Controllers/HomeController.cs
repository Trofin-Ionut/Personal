﻿using Microsoft.AspNetCore.Mvc;

namespace Layout_Views.Controllers
{
    public class HomeController : Controller
    {
        [Route("/")]
        public IActionResult Home()
        {
            return View();
        }
        [Route("About")]
        public IActionResult About() 
        {
            return View();
        }
    }
}
