﻿namespace StocksApp_Configuration_chapter_.Services
{
    public class Service
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public Service(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }
        public async Task NewClient()
        {
            using (HttpClient httpClient = _httpClientFactory.CreateClient())
            { //this Uri is actually an API key. Pretty cool thing to request and get info from other REAL sites
                HttpRequestMessage httpRequestMessage = new HttpRequestMessage() 
                { 
                    RequestUri=new Uri("https://finnhub.io/api/v1/quote?symbol=AAPL&token=ck62nt9r01qls0umf62gck62nt9r01qls0umf630"), 
                    Method=HttpMethod.Get
                };
                HttpResponseMessage httpResponseMessage= await httpClient.SendAsync(httpRequestMessage);
                Stream stream= await httpResponseMessage.Content.ReadAsStreamAsync();
                StreamReader reader = new StreamReader(stream);
                string content= await reader.ReadToEndAsync();
            }
        }
    }
}
