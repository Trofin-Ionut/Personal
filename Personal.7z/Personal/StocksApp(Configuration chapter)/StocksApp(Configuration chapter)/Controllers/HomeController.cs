﻿using Microsoft.AspNetCore.Mvc;
using StocksApp_Configuration_chapter_.Services;

namespace StocksApp_Configuration_chapter_.Controllers
{
    public class HomeController : Controller
    {
        private readonly Service _service;

        public HomeController(Service service)
        {
            _service = service;
        }

        [Route("/")]
        public async Task<IActionResult> Index()
        {
            await _service.NewClient();
            return View();
        }
    }
}
