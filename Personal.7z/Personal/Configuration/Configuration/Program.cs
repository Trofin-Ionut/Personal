using Microsoft.AspNetCore.Http;
using Configuration.Models;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
//you can add the configuration as an service aswell. It will supply an objectfor your needs
builder.Services.Configure<MasterOptions>(builder.Configuration.GetSection("MyMasterKey"));

//if you want to use a custom json file for config, etc, you need to add it in the Program.cs like this:
builder.Host.ConfigureAppConfiguration((hostingCoontext, config) =>
{
    config.AddJsonFile("CustomJson.json", optional: true, reloadOnChange: true); //optional:true => file is optional. If it doesn't exist, it won't throw error
    //reloadOnChange:true => if any change is made to this json file, the app will restart automatically
}); //somehow, a custom json has the highest priority, even if a secrets manager exists(the s.m. stuff won't pop us if what you seek is only in that apparently, i think)

var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.UseEndpoints(endpoints =>
{
    endpoints.Map("/configTest", async context =>
    {
        await context.Response.WriteAsync(app.Configuration["MyKey"] +"\n"); //note: .Configuration["..."] is not case sensitive, ex: myKEY would return the same result.

        //another way of getting the configuration stuff:( it checks if the value exists or not and returns null if it doesn't exist. The one above just throws error
        await context.Response.WriteAsync(app.Configuration.GetValue<string>("MyKey"));

        //third way with default value
        await context.Response.WriteAsync(app.Configuration.GetValue<int>("y",10)+"\n"); //here defaultValue= 10. It shows 10 if "y" is not present in configuration
    });
});
app.MapControllers();

app.Run();

//for secrets manager:

//1: open View->terminal
//2: cd [project name]
//3: dotner user-secrets init
//4: right-click on project(not solution) -> Manage User Secrets. Note: the file is not meant to be coded directly, or not even opened sometimes.Don't write stuff dirrectly into that file
//5: dotnet user-secrets set "key/ masterkey:key1" [space] "[value]". Here: "MyMasterKey:Key1" "chaos from user secrets" => stores data in the secrets.json from config files

//for environment variables:

//$Env:[parentkey]__[childkey]="[value]" ex:  $Env:MyMasterKey__key1="Key1 from environment variables"

//dotnet --no-launch-profile => 