using StocksApp_Configuration_chapter_.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient(); //this adds IHttpClientFactory to the IServiceCollection, so it can be an injectable interface and apply DIP
//IHttpClientFactory has .CreateClient() that creates a new instance of HttpClient and disposes of the object (closes connection), immediately after usage. (as soon as possible)
//look in the Service class at public method. (you need to use in a using block)
builder.Services.AddScoped<FinnhubService>();
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.MapControllers();

app.Run();
