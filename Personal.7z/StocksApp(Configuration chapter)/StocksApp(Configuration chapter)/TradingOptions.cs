﻿namespace StocksApp_Configuration_chapter_
{
    public class TradingOptions
    {
        public string? DefaultStockSymbol{get;set;}
    }
}
