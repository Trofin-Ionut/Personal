﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using StocksApp_Configuration_chapter_.Models;
using StocksApp_Configuration_chapter_.Services;

namespace StocksApp_Configuration_chapter_.Controllers
{
    public class HomeController : Controller
    {
        private readonly FinnhubService _finnhubService;
        private readonly IOptions<TradingOptions> _tradingOptions;

        public HomeController(FinnhubService service,IOptions<TradingOptions>tradingOptions)
        {
            _finnhubService = service;
            _tradingOptions = tradingOptions;
        }

        [Route("/")]
        public async Task<IActionResult> Index()
        {
            if(_tradingOptions.Value.DefaultStockSymbol==null)
            {
                _tradingOptions.Value.DefaultStockSymbol = "MSFT";
            }
           
            Dictionary<string,object> contentDictionary=await _finnhubService.GetStockPriceQuote(_tradingOptions.Value.DefaultStockSymbol);
            Stock stock = new Stock()
            {
                StockSymbol = _tradingOptions.Value.DefaultStockSymbol,
                CurrentPrice = Convert.ToDouble(contentDictionary["c"].ToString()),
                HighestPrice = Convert.ToDouble(contentDictionary["h"].ToString()),
                LowestPrice = Convert.ToDouble(contentDictionary["l"].ToString()),
                OpenPrice = Convert.ToDouble(contentDictionary["o"].ToString())
            };

            return View(stock);
        }
    }
}
