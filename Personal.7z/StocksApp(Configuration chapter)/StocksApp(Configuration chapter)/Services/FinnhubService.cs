﻿using StocksApp_Configuration_chapter_.ServiceContracts;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;

namespace StocksApp_Configuration_chapter_.Services
{
    public class FinnhubService : IFinnhubService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        public FinnhubService(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }
        public async Task<Dictionary<string, object>> GetStockPriceQuote(string stockSymbol)
        {
            using (HttpClient httpClient = _httpClientFactory.CreateClient())
            { //this Uri is actually a link to the online platform with your API access key given by them. Pretty cool thing to request and get info from other REAL sites
                HttpRequestMessage httpRequestMessage = new HttpRequestMessage()
                {
                    //you can use _configuration to insert the api key from user secrets and you can use a parameter for the symbol chosen instead
                    //of writing the whole link like this.
                    RequestUri = new Uri($"https://finnhub.io/api/v1/quote?symbol={stockSymbol}&token={_configuration["finnhubToken"]}"),
                    Method = HttpMethod.Get
                };
                HttpResponseMessage httpResponseMessage = await httpClient.SendAsync(httpRequestMessage);
                Stream stream = await httpResponseMessage.Content.ReadAsStreamAsync();
                StreamReader reader = new StreamReader(stream);
                string content = await reader.ReadToEndAsync();                         //return type            +   item to convert
                Dictionary<string, object>? contentDictionary = JsonSerializer.Deserialize<Dictionary<string, object>>(content);
                return contentDictionary;
            }
        }
    }
}
