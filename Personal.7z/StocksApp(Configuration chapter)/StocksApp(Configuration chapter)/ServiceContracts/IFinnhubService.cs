﻿namespace StocksApp_Configuration_chapter_.ServiceContracts
{
    public interface IFinnhubService
    {
        Task<Dictionary<string, object>> GetStockPriceQuote(string stockSymbol);
    }
}
