﻿using Entities;
using ServiceContracts.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ServiceContracts.DTO
{
    public class PersonUpdateRequest
    {
        public Guid PersonId { get; set; }
        [Required(ErrorMessage = "Name can't be blank")]
        public string? PersonName { get; set; }
        [Required(ErrorMessage = "Email can't be blank")]
        [EmailAddress(ErrorMessage = "Email must be in the email format")]
        public string? Email { get; set; }
        public DateTime? DateOfBirth { get; set; }
        [Required(ErrorMessage = "You must belong to a certain gender")]
        public GenderOptions Gender { get; set; }
        public Guid? CountryId { get; set; }

        public string Country { get;set; }

        public Person ToPerson() => new Person(PersonId,PersonName, Email, DateOfBirth, Gender.ToString(), CountryId);

        public PersonUpdateRequest(Guid personId, string? personName, string? email, DateTime? dateOfBirth, GenderOptions gender, Guid? countryId, string country)
        {
            PersonId = personId;
            PersonName = personName;
            Email = email;
            DateOfBirth = dateOfBirth;
            Gender = gender;
            CountryId = countryId;
            Country = country;
        }

        public PersonUpdateRequest()
        {
        }
    }
}
