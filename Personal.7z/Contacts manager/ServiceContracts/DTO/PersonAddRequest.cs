﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceContracts.Enums;
using Entities;
using System.Reflection.Metadata.Ecma335;
using System.ComponentModel.DataAnnotations;

namespace ServiceContracts.DTO
{
    //model validation (classic). Best way to deal with the tests really
    public class PersonAddRequest
    {
        [Required(ErrorMessage ="Name can't be blank")]
        public string? PersonName { get; set; }
        [Required(ErrorMessage ="Email can't be blank")]
        [EmailAddress(ErrorMessage ="Email must be in the email format")]
        public string? Email { get; set; }
        public DateTime? DateOfBirth { get; set; }
        [Required(ErrorMessage ="You must belong to a certain gender")]
        public GenderOptions Gender { get; set; }
        public Guid? CountryId { get; set; } //foreign key
        [Required(ErrorMessage ="We need to know where you live")]
        public string? Address { get; set; }
        [Required(ErrorMessage ="Do you want news letters or not? We need to know")]
        public bool ReceiveNewsLetters { get; set; }

        public Person ToPerson() => new Person(PersonName,Email,DateOfBirth,Gender.ToString(),CountryId,Address,ReceiveNewsLetters);
    }
}
