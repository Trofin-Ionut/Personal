﻿using ServiceContracts.DTO;

namespace ServiceContracts
{/// <summary>
/// Represents business logic for manipulating Country entity
/// </summary>
    public interface ICountriesService
    {
        /// <summary>
        /// Adds a country object to the list of countries
        /// </summary>
        /// <param name="request"></param>
        /// <returns>
        /// Returns the country object after adding it(including newly generated CountryId)
        /// </returns>
        CountryResponse AddCountry(CountryAddRequest? request);
    }
}