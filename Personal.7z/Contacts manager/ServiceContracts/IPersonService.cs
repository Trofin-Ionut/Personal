﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceContracts.DTO;

namespace ServiceContracts
{
    public interface IPersonService
    {
        PersonResponse AddPerson(PersonAddRequest request);
        List<PersonResponse>? GetPeople();
        /// <summary>
        /// Returns object based by it's id
        /// </summary>
        /// <param name="personId"></param>
        /// <returns> Returns matching person object</returns>
        PersonResponse? GetPersonByPersonId(Guid? personId);
    }
}
