﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceContracts.DTO;
using ServiceContracts.Enums;

namespace ServiceContracts
{
    public interface IPersonService
    {
        PersonResponse AddPerson(PersonAddRequest request);
        List<PersonResponse>? GetPeople();
        /// <summary>
        /// Returns object based by it's id
        /// </summary>
        /// <param name="personId"></param>
        /// <returns> Returns matching person object</returns>
        PersonResponse? GetPersonByPersonId(Guid? personId);
        /// <summary>
        /// Returns all Person objects that match the item category search (like name, id, email, etc) and the actual string you'll input for
        /// the exact thing you're looking for
        /// </summary>
        /// <param name="searchCategory">Search field to search</param>
        /// <param name="searchString">Search string to search</param>
        /// <returns>Returns all matching Person objects based on the parameters given</returns>
        List<PersonResponse> GetFilteredPerson(string searchCategory, string? searchString);
        /// <summary>
        /// Returns sorted list of persons
        /// </summary>
        /// <param name="allPeople">The list of people to sort</param>
        /// <param name="sortBy">The object's property(key) based on which the persons should be sorted</param>
        /// <param name="option">ASC OR DESC</param>
        /// <returns> Returns sorted persons as a List<PersonResponse> </returns>
        List<PersonResponse> GetSortedPersons(List<PersonResponse> allPeople, string sortBy, SortOrderOptions option);
        /// <summary>
        /// Updates the person based by it's PersonId
        /// </summary>
        /// <param name="request">Person details to update with the PersonId</param>
        /// <returns>Returns the Person object after update</returns>
        PersonResponse UpdatePerson(PersonUpdateRequest? request);
    }
}
