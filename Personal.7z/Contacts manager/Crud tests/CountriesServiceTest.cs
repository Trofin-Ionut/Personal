﻿using ServiceContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Services;
using ServiceContracts.DTO;

namespace Crud_tests
{
    public class CountriesServiceTest
    {
        private readonly ICountriesService _countriesService;

        public CountriesServiceTest()
        {
            _countriesService = new CountryService();
        }

        [Fact]  //unit test decorator => tells the IDE this is a test method
        //When CountryAddRequest == null => must throw ArgumentNullException
        public void AddCountry_NullCountry()   //normally, it is Arrange => Act => Assert (here Act is within the Assert stage)
        {
            //Arrange
            CountryAddRequest? request = null;

            //Assert
                    //Act
            Assert.Throws<ArgumentNullException>(() => _countriesService.AddCountry(request)); //it's ok if it throws exception. that's what you are looking for when null
        }
        //When CountryName is null => ArgumentException

        [Fact]
        public void AddCountry_CountryNameIsNull()
        {
            CountryAddRequest request = new() { CountryName=null};

            Assert.Throws<ArgumentException>(()=> _countriesService.AddCountry(request));
        }

        //When CountryName is duplicated => Argument Exception

        [Fact]
        public void AddCountry_DuplicateCountryName() 
        {
            CountryAddRequest request1 = new() { CountryName = "Romania" };
            CountryAddRequest request2 = new() { CountryName = "Romania" };

            Assert.Throws<ArgumentException>(() =>
            {
                _countriesService.AddCountry(request1);
                _countriesService.AddCountry(request2);
            });
        }
        //When you supply country name, it should insert the country in the existing list of countries

        [Fact]
        public void AddCountry_ProperCountryDetails()
        {
            //Assert
            CountryAddRequest request = new() { CountryName = "USA" };
            //Act
            CountryResponse response= _countriesService.AddCountry(request); //in a context where you're testing something THAT WORKS, you use the CountryResponse
            //Assert 
            Assert.True(response.CountryId != Guid.Empty);
        }
    }
}
