﻿namespace Crud_tests
{
    public class ClassForTestingExample
    {
        public int Sum (int a,int b)
        {
            return a + b;
        }
    }
}
