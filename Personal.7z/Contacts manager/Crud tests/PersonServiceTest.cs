﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using ServiceContracts;
using Services;
using ServiceContracts.DTO;
using ServiceContracts.Enums;
using Xunit.Abstractions;
using Xunit.Sdk;
using Entities;

namespace Crud_tests
{
    public class PersonServiceTest
    {
        private readonly IPersonService _personService;
        private readonly ICountriesService _countriesService;
        private readonly ITestOutputHelper _testOutputHelper;

        public PersonServiceTest(ITestOutputHelper testHelperOutput)
        {
            _personService = new PersonService();
            _countriesService = new CountryService();
            _testOutputHelper = testHelperOutput;
        }
        #region AddPerson
        [Fact]
        public void AddPerson_NullPerson()
        {
            //Arrange
            PersonAddRequest? request = null;

            //Act+Assert
            Assert.Throws<ArgumentNullException>(() => _personService.AddPerson(request));
        }
        public void AddPerson_NullPersonName()
        {
            PersonAddRequest? request = new() { PersonName = null };

            Assert.Throws<ArgumentException>(() => _personService.AddPerson(request));
        }
        public void AddPerson_ProperPersonDetails()
        {
            //Arrange
            PersonAddRequest? request = new()
            {
                PersonName = "Johnny",
                Address = "St. Pain",
                CountryId = Guid.NewGuid(),
                DateOfBirth = DateTime.Now,
                Email = "lala.lulu@stupid.com",
                Gender = GenderOptions.Male,
                ReceiveNewsLetters = false
            };

            //Act
            PersonResponse response = _personService.AddPerson(request);

            //Assert => you just want to see if it was added. Reason why you check if the new property isn't empty.
            Assert.True(response.PersonId != Guid.Empty);
        }
        #endregion
        #region GetPersonByPersonId
        [Fact]
        public void GetPersonByPersonId_NullPersonId()
        {
            //Arrange
            Guid? personId = null;

            //Assert+Act
            Assert.Throws<ArgumentNullException>(() => _personService.GetPersonByPersonId(personId));
        }
        [Fact]
        public void GetPersonByPersonId_WithPersonId()
        {
            //Arrange
            CountryAddRequest countryRequest = new() { CountryName = "USA" };
            CountryResponse countryResponse = _countriesService.AddCountry(countryRequest);
            //Act
            PersonAddRequest personAddRequest = new()
            {
                Address = "1",
                CountryId = countryResponse.CountryId,
                DateOfBirth = DateTime.Parse("2001-09-15"),
                Email = "...@..,com",
                Gender = GenderOptions.Male,
                PersonName = "Jonathan",
                ReceiveNewsLetters = false
            };
            PersonResponse personResponse = _personService.AddPerson(personAddRequest);
            PersonResponse? found = _personService.GetPersonByPersonId(personResponse.PersonId);

            //Assert
            Assert.Equal(personResponse, found);

        }
        #endregion
        #region GetPeople
        //The .GetPeople() should return an empty list as default value. This is a requirement at implementation stage.
        //These tests put implementation requirements and constraints on implementation
        [Fact]
        public void GetPeople_DefaultCase()
        {
            Assert.Empty(_personService.GetPeople());
        }
        private void InitialisingStage(ref List<PersonResponse> initialResponses)
        {
            CountryAddRequest c1 = new() { CountryName = "USA" };
            CountryAddRequest c2 = new() { CountryName = "UK" };
            CountryResponse rc1 = _countriesService.AddCountry(c1);
            CountryResponse rc2 = _countriesService.AddCountry(c2);

            PersonAddRequest p1 = new()
            {
                Address = "1",
                CountryId = rc1.CountryId,
                DateOfBirth = DateTime.Parse("2002-01-10"),
                Email = "2@hell.com",
                Gender = GenderOptions.Male,
                PersonName = "Michael",
                ReceiveNewsLetters = true
            };
            PersonAddRequest p2 = new()
            {
                Address = "2",
                CountryId = rc2.CountryId,
                DateOfBirth = DateTime.Parse("2004-01-10"),
                Email = "3@dam.com",
                Gender = GenderOptions.Female,
                PersonName = "Hannah",
                ReceiveNewsLetters = false
            };
            PersonAddRequest p3 = new()
            {
                Address = "3",
                CountryId = rc1.CountryId,
                DateOfBirth = DateTime.Parse("2000-05-25"),
                Email = "4@heaven.com",
                Gender = GenderOptions.Other,
                PersonName = "Destroyer of worlds",
                ReceiveNewsLetters = true
            };
            List<PersonAddRequest> requests = new() { p1, p2, p3 };
            foreach (PersonAddRequest request in requests)
            {
                initialResponses.Add(_personService.AddPerson(request));
            }
        }
        //The method should work properly, reason why here a few people will be added and then tested to see if the content is alright;
        [Fact]
        public void GetPeople_FunctionsWell()
        {
            //Arrange
            List<PersonResponse> initialResponses = new();
            InitialisingStage(ref initialResponses);
            //Act
            List<PersonResponse>? finalResponses = _personService.GetPeople();

            //Bonus, print initialResponses:
            _testOutputHelper.WriteLine("Expected:");
            foreach (PersonResponse person in initialResponses) { _testOutputHelper.WriteLine(person.ToString()); }

            _testOutputHelper.WriteLine("Actual:");
            foreach (PersonResponse? person in finalResponses) { _testOutputHelper.WriteLine(person.ToString()); }
            //Assert
            foreach (PersonResponse response in initialResponses) { Assert.Contains(response, finalResponses); }

        }
        #endregion
        #region GetFilteredPerson

        [Fact]
        public void GetFilteredPerson_EmptySearchString()
        {
            //Arrange
            List<PersonResponse> initialResponses = new();
            InitialisingStage(ref initialResponses);
            //Act
            List<PersonResponse>? finalResponses = _personService.GetFilteredPerson("PersonName", "");

            //Bonus, print initialResponses:
            _testOutputHelper.WriteLine("Expected:");
            foreach (PersonResponse person in initialResponses) { _testOutputHelper.WriteLine(person.ToString()); }

            _testOutputHelper.WriteLine("Actual:");
            foreach (PersonResponse? person in finalResponses) { _testOutputHelper.WriteLine(person.ToString()); }
            //Assert
            foreach (PersonResponse response in initialResponses) { Assert.Contains(response, finalResponses); }
        }

        //This time, we test to see if the searchString actually works properly

        [Fact]
        public void GetFilteredPerson_FunctionalSearchString()
        {
            //Arrange
            List<PersonResponse> initialResponses = new();
            InitialisingStage(ref initialResponses);
            string searchCategory = "PersonName";
            string? searchString = "a";

            //Act
            List<PersonResponse>? finalResponses = _personService.GetFilteredPerson(searchCategory, searchString);

            //Assert
            foreach (PersonResponse response in initialResponses)
            {
                if (response.PersonName != null && response.PersonName.Contains(searchString, StringComparison.OrdinalIgnoreCase))
                {
                    Assert.Contains(response, finalResponses);
                }
            }

        }
        #endregion

        #region GetSortedPersons
        //When Desc order is enabled, it should actually sort the objects in a descending order
        [Fact]
        public void GetSortedPersons_()
        {
            List<PersonResponse> initialResponses = new();
            InitialisingStage(ref initialResponses);

            //Act
            List<PersonResponse>? finalResponses = _personService.GetSortedPersons(_personService.GetPeople(), nameof(Person.PersonName), SortOrderOptions.DESC);
            initialResponses = initialResponses.OrderByDescending(person => person.PersonName).ToList();

            //Assert
            for (int i = 0; i < finalResponses.Count; i++) { Assert.Equal(initialResponses[i], finalResponses[i]); }
        }
        #endregion
        #region UpdatePerson
        //When a null PersonUpdateRequest is supplied, it should throw ArgumentNullException
        [Fact]
        public void UpdatePerson_NullUpdateRequest()
        {
            //Arrange
            PersonUpdateRequest? request = null;

            //Assert+Act
            Assert.Throws<ArgumentNullException>(() =>
            {
                _personService.UpdatePerson(request);
            });
        }
        //When invalid PersonId is supplied, ArgumentException is the answer
        [Fact]
        public void UpdatePerson_InvalidId()
        {
            //Arrange
            PersonUpdateRequest? request = new() { PersonId = Guid.NewGuid() };
            //Assert+Act
            Assert.Throws<ArgumentException>(() =>
            {
                _personService.UpdatePerson(request);
            });

        }
        #endregion
    }
}
