﻿using ServiceContracts;
using ServiceContracts.DTO;
using Entities;

namespace Services
{
    public class CountryService : ICountriesService
    {
        private readonly List<Country> _countries;
        //this is from the tester's perspective. He usually puts dummy or not implemented values
        public CountryService(bool initialise=true)
        {
            _countries = new();
            if(initialise) 
            {
                _countries.AddRange(new List<Country>()
                {
                    new Country(){CountryId=Guid.Parse("BE32009F-9A0F-4BB6-94CB-7C873D2C4EE1"),CountryName="Romania"},
                    new Country(){CountryId=Guid.Parse("338FA6E3-66FC-438F-A39F-DD6ECFB63217"),CountryName="Ukrain"},
                    new Country(){CountryId=Guid.Parse("1B650D4C-C2A1-4F88-8FF3-933EC8C1C213"),CountryName="Budapesta"},
                    new Country(){CountryId=Guid.Parse("AA2AB2B5-3C84-48E2-AD62-3FC72A279C7D"),CountryName="Italy"},
                    new Country(){CountryId=Guid.Parse("26375FF8-7628-489E-9B61-083FB15A62C9"),CountryName="Afghanistan"},
                });
            }
        }
        public CountryResponse AddCountry(CountryAddRequest? request)
        {
            //Validation: if the request is null
            if(request == null)  throw new ArgumentNullException(nameof(request)); 

            //Validation: if CountryName is null
            if (request.CountryName == null)  throw new ArgumentException(nameof(request.CountryName)); 

            //Validation: if duplicate country names exist
            if(_countries.Where(country => country.CountryName.Equals(request.CountryName)).Any())  throw new ArgumentException("Country name already exists\n"); 

            //Convert CountryAddRequest object to Country type
            Country country = request.ToCountry();

            //Generate countryId
            country.CountryId= Guid.NewGuid();

            //Add object country into the list
            _countries.Add(country);

            //return object as an CountryResponse object
            return country.ToCountryResponse();
        }

        public List<CountryResponse> GetAllCountries()
        {
            return _countries.Select(country=> country.ToCountryResponse()).ToList();
        }

        public CountryResponse GetCountryByCountryID(Guid? countryId)
        {
            if(countryId == null)  return null;

            if (_countries.FirstOrDefault(country => country.CountryId.Equals(countryId)) is Country found) return found.ToCountryResponse();

            return null;
        }
    }
}