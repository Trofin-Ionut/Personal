﻿using Entities;
using Microsoft.VisualBasic;
using ServiceContracts;
using ServiceContracts.DTO;
using ServiceContracts.Enums;
using Services.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Xunit.Abstractions;

namespace Services
{
    public class PersonService : IPersonService
    {
        private readonly List<Person> _persons;
        private readonly ICountriesService _countryService;

        public PersonService(bool initialise = true)
        {
            _persons = new List<Person>();
            _countryService = new CountryService(false);
            if (initialise)
            {
                _persons.AddRange(new List<Person>()
                {
                    //To do yourself: choose countryIds to insert here from the mocking part of countryService
                    new Person(){PersonId=Guid.Parse("1350b2ba-e531-4f61-b1a8-a309f5e7a4bc"),PersonName="Aymer",Email="amurford0@whitehouse.gov",DateOfBirth=DateTime.Parse("6/4/2004"),Gender=nameof(GenderOptions.Male),Address="60722 Waubesa Place",ReceiveNewsLetters=false},
                    new Person(){PersonId=Guid.Parse("a38121f6-2cd5-403f-8eb4-ebf1938be09f"),PersonName="Brietta",Email="bdonaho1@guardian.co.uk",DateOfBirth=DateTime.Parse("12/11/2001"),Gender=nameof(GenderOptions.Female),Address="Declaration Terrace",ReceiveNewsLetters=true },
                    new Person(){PersonId=Guid.Parse("1b610bc9-6059-4dad-b511-4b233124b35e"),PersonName="Berkley",Email="bdaughtery2@wp.com",DateOfBirth=DateTime.Parse("1/25/2022"),Gender=nameof(GenderOptions.Male),Address="00 Birchwood Junction",ReceiveNewsLetters=true },
                    new Person(){PersonId=Guid.Parse("878288a7-ff56-44fb-b16d-091c6f79cb18"),PersonName="Ivan",Email="isweetman3@barnesandnoble.com",DateOfBirth=DateTime.Parse("7/18/2013"),Gender=nameof(GenderOptions.Male),Address="77 Dawn Road",ReceiveNewsLetters=true },
                    new Person(){PersonId=Guid.Parse("d35fba15-6e09-41a3-b759-d9d530933a7d"),PersonName="Sutherlan",Email="sbursell4@hp.com",DateOfBirth=DateTime.Parse("4/16/2009"),Gender=nameof(GenderOptions.Male),Address="15497 Victoria Plaza",ReceiveNewsLetters=true },
                    new Person(){PersonId=Guid.Parse("6346d748-d5fd-4eed-bff6-229a3e000b13"),PersonName="Caroljean",Email="cidiens5@eepurl.com",DateOfBirth=DateTime.Parse("1/30/2023"),Gender=nameof(GenderOptions.Female),Address="711 International Court",ReceiveNewsLetters=true },
                    });
            }
        }
        private PersonResponse FromPersonToPersonResponse(ref Person person)
        {
            PersonResponse response = person.ToPersonResponse();
            response.Country = _countryService.GetCountryByCountryID(person.CountryId)?.CountryName;
            return response;
        }

        public PersonResponse AddPerson(PersonAddRequest request)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (string.IsNullOrEmpty(request.PersonName)) throw new ArgumentException("Person's name is empty");

            //Model validation
            ValidationHelper.ModelValidation(request);

            Person person = request.ToPerson();

            person.PersonId = Guid.NewGuid();

            _persons.Add(person);

            return FromPersonToPersonResponse(ref person);
        }

        public List<PersonResponse> GetPeople()
        {
            return _persons.Select(person => person.ToPersonResponse()).ToList();
        }

        public PersonResponse? GetPersonByPersonId(Guid? personId)
        {
            if (personId == null) throw new ArgumentNullException(nameof(personId));

            return _persons.FirstOrDefault(person => person.PersonId.Equals(personId))?.ToPersonResponse();

        }

        public List<PersonResponse> GetFilteredPerson(string searchCategory, string? searchString)
        {
            List<PersonResponse> allPeople = GetPeople();
            List<PersonResponse> matches = new();
            if (string.IsNullOrEmpty(searchCategory)) return allPeople;

            switch (searchCategory)
            {
                case nameof(PersonResponse.PersonName):
                    if (searchString == null) return allPeople.Where(person => nameof(person.PersonName).Equals(nameof(PersonResponse.PersonName))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.PersonName) ? false : person.PersonName.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(PersonResponse.Address):
                    if (searchString == null) return allPeople.Where(person => nameof(person.Address).Equals(nameof(PersonResponse.Address))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.Address) ? false : person.Address.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(PersonResponse.Email):
                    if (searchString == null) return allPeople.Where(person => nameof(person.Email).Equals(nameof(PersonResponse.Email))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.Email) ? false : person.Email.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(PersonResponse.Gender):
                    if (searchString == null) return allPeople.Where(person => nameof(person.Gender).Equals(nameof(PersonResponse.Gender))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.Gender) ? false : person.Gender.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(PersonResponse.CountryId):
                    if (searchString == null) return allPeople.Where(person => nameof(person.CountryId).Equals(nameof(PersonResponse.CountryId))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.CountryId.ToString()) ? false : person.CountryId.ToString().Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;
                case nameof(PersonResponse.DateOfBirth):
                    if (searchString == null) return allPeople.Where(person => nameof(person.DateOfBirth).Equals(nameof(PersonResponse.DateOfBirth))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.DateOfBirth.Value.ToString("dd.MM.yyyy")) ? false : person.DateOfBirth.Value.ToString("dd.MM.yyyy").Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;
                default:
                    matches = allPeople;
                    break;
            }
            return matches;
        }

        public List<PersonResponse> GetSortedPersons(List<PersonResponse> allPeople, string sortBy, SortOrderOptions option)
        {
            if (string.IsNullOrEmpty(sortBy)) return allPeople;

            List<PersonResponse> sorted = (sortBy, option) switch
            {
                (nameof(PersonResponse.PersonName), SortOrderOptions.ASC) //this is the case [value] : in this context 
                => allPeople.OrderBy(person => person.PersonName, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.PersonName), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.PersonName, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Email), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Email, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Email), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.Email, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.DateOfBirth), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.DateOfBirth.Value.ToString("dd/MM/yyyy"), StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.DateOfBirth), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.DateOfBirth.Value.ToString("dd/MM/yyyy"), StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Age), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Age.ToString(), StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Age), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.Age.ToString(), StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Gender), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Gender, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Gender), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.Gender, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Address), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Address, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Address), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.Address, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.ReceiveNewsLetters), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.ReceiveNewsLetters).ToList(),

                (nameof(PersonResponse.ReceiveNewsLetters), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.ReceiveNewsLetters).ToList(),

                _ => allPeople //here " _ " means "default" case.

            };
            return sorted;
        }

        public PersonResponse UpdatePerson(PersonUpdateRequest? request)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));

            //Validation
            ValidationHelper.ModelValidation(request);

            if (GetPersonByPersonId(request.PersonId) is not PersonResponse found) throw new ArgumentNullException(nameof(request.PersonId));

            found = request.ToPerson().ToPersonResponse();

            return found;
        }

        public bool DeletePerson(Guid? personId)
        {
            if (personId == null) return false;

            return _persons.Remove(_persons.FirstOrDefault(person => person.PersonId.Equals(personId)));
        }
    }
}
