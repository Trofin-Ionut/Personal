﻿using Entities;
using Microsoft.VisualBasic;
using ServiceContracts;
using ServiceContracts.DTO;
using ServiceContracts.Enums;
using Services.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using Xunit.Abstractions;

namespace Services
{
    public class PersonService : IPersonService
    {
        private readonly List<Person> _persons;
        private readonly ICountriesService _countryService;

        public PersonService() 
        { 
            _persons = new List<Person>(); 
            _countryService = new CountryService(); 
        }
        
        private PersonResponse FromPersonToPersonResponse(ref Person person)
        {
            PersonResponse response = person.ToPersonResponse();
            response.Country=_countryService.GetCountryByCountryID(person.CountryId)?.CountryName;
            return response;
        }

        public PersonResponse AddPerson(PersonAddRequest request)
        {
            if(request == null) throw new ArgumentNullException(nameof(request));
            if(request.PersonName==null || request.PersonName.Equals("")) throw new ArgumentException("Person's name is empty");

            //Model validation
            ValidationHelper.ModelValidation(request);

            Person person = request.ToPerson();

            person.PersonId=Guid.NewGuid();

            _persons.Add(person);

            return FromPersonToPersonResponse(ref person);
        }

        public List<PersonResponse> GetPeople()
        {
            return _persons.Select(person => person.ToPersonResponse()).ToList();
        }

        public PersonResponse? GetPersonByPersonId(Guid? personId)
        {
            if(personId == null) throw new ArgumentNullException(nameof(personId));

            return _persons.FirstOrDefault(person => person.PersonId.Equals(personId))?.ToPersonResponse();

        }

        public List<PersonResponse> GetFilteredPerson(string searchCategory, string? searchString)
        {
            List<PersonResponse> allPeople = GetPeople();
            List<PersonResponse> matches = new();
           if(string.IsNullOrEmpty(searchCategory)) return allPeople;

           switch(searchCategory) 
            {
                case nameof(Person.PersonName):
                    if(searchString == null) return allPeople.Where(person => nameof(person.PersonName).Equals(nameof(Person.PersonName))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.PersonName) ? false : person.PersonName.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(Person.Address):
                    if (searchString == null) return allPeople.Where(person => nameof(person.Address).Equals(nameof(Person.Address))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.Address) ? false : person.Address.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(Person.Email):
                    if (searchString == null) return allPeople.Where(person => nameof(person.Email).Equals(nameof(Person.Email))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.Email) ? false : person.Email.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(Person.Gender):
                    if (searchString == null) return allPeople.Where(person => nameof(person.Gender).Equals(nameof(Person.Gender))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.Gender) ? false : person.Gender.Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;

                case nameof(Person.CountryId):
                    if (searchString == null) return allPeople.Where(person => nameof(person.CountryId).Equals(nameof(Person.CountryId))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.CountryId.ToString()) ? false : person.CountryId.ToString().Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;
                case nameof(Person.DateOfBirth):
                    if(searchString==null) return allPeople.Where(person => nameof(person.DateOfBirth).Equals(nameof(Person.DateOfBirth))).ToList();

                    matches = allPeople.Where(person => (string.IsNullOrEmpty(person.DateOfBirth.Value.ToString("dd.MM.yyyy")) ? false : person.DateOfBirth.Value.ToString("dd.MM.yyyy").Contains(searchString, StringComparison.OrdinalIgnoreCase))).ToList();
                    break;
                default:
                    matches = allPeople;
                    break;
            }
            return matches;
        }

        public List<PersonResponse> GetSortedPersons(List<PersonResponse> allPeople, string sortBy, SortOrderOptions option)
        {
            if(string.IsNullOrEmpty(sortBy)) return allPeople;

            List<PersonResponse> sorted = (sortBy, option) switch
            {
                (nameof(PersonResponse.PersonName),SortOrderOptions.ASC) //this is the case [value] : in this context 
                => allPeople.OrderBy(person => person.PersonName,StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.PersonName),SortOrderOptions.DESC)
                =>allPeople.OrderByDescending(person => person.PersonName,StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Email),SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Email,StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Email),SortOrderOptions.DESC)
                =>allPeople.OrderByDescending(person => person.Email,StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.DateOfBirth),SortOrderOptions.ASC) 
                => allPeople.OrderBy(person => person.DateOfBirth.Value.ToString("dd/MM/yyyy"),StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.DateOfBirth),SortOrderOptions.DESC)
                =>allPeople.OrderByDescending(person => person.DateOfBirth.Value.ToString("dd/MM/yyyy"),StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Age), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Age.ToString(), StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Age), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.Age.ToString(), StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Gender), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Gender, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Gender), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.Gender, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Address), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.Address, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.Address), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.Address, StringComparer.OrdinalIgnoreCase).ToList(),

                (nameof(PersonResponse.ReceiveNewsLetters), SortOrderOptions.ASC)
                => allPeople.OrderBy(person => person.ReceiveNewsLetters).ToList(),

                (nameof(PersonResponse.ReceiveNewsLetters), SortOrderOptions.DESC)
                => allPeople.OrderByDescending(person => person.ReceiveNewsLetters).ToList(),

                _ => allPeople //here " _ " means "default" case.

            };
            return sorted;
        }

        public PersonResponse UpdatePerson(PersonUpdateRequest? request)
        {
            throw new NotImplementedException();
        }
    }
}
