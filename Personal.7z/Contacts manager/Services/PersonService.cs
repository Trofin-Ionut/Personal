﻿using Entities;
using ServiceContracts;
using ServiceContracts.DTO;
using Services.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit.Abstractions;

namespace Services
{
    public class PersonService : IPersonService
    {
        private readonly List<Person> _persons;
        private readonly ICountriesService _countryService;

        public PersonService() 
        { 
            _persons = new List<Person>(); 
            _countryService = new CountryService(); 
        }
        
        private PersonResponse FromPersonToPersonResponse(ref Person person)
        {
            PersonResponse response = person.ToPersonResponse();
            response.Country=_countryService.GetCountryByCountryID(person.CountryId)?.CountryName;
            return response;
        }

        public PersonResponse AddPerson(PersonAddRequest request)
        {
            if(request == null) throw new ArgumentNullException(nameof(request));
            if(request.PersonName==null || request.PersonName.Equals("")) throw new ArgumentException("Person's name is empty");

            //Model validation
            ValidationHelper.ModelValidation(request);

            Person person = request.ToPerson();

            person.PersonId=Guid.NewGuid();

            _persons.Add(person);

            return FromPersonToPersonResponse(ref person);
        }

        public List<PersonResponse>? GetPeople()
        {
            return _persons.Select(person => person.ToPersonResponse()).ToList();
        }

        public PersonResponse? GetPersonByPersonId(Guid? personId)
        {
            if(personId == null) throw new ArgumentNullException(nameof(personId));

            return _persons.FirstOrDefault(person => person.PersonId.Equals(personId))?.ToPersonResponse();

        }
    }
}
