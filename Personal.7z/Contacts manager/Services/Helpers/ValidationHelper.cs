﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Helpers
{
    public class ValidationHelper
    {
        internal static void ModelValidation (object obj)
        {
            //model validation
            ValidationContext validation = new(obj);
            List<ValidationResult> results = new();
            //looks through the object's properties and compares them with the class's model validation attributes. If the 4th parameter is
            //ignored or false, then it only looks for validation from the required properties. If it's true => seeks validation from all properties
            bool validated = Validator.TryValidateObject(obj, validation, results, true);

            if (!validated) throw new ArgumentException(results.FirstOrDefault()?.ErrorMessage);
        }
    }
}
