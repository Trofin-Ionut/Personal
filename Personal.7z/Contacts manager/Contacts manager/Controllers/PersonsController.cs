﻿using Microsoft.AspNetCore.Mvc;

namespace Contacts_manager.Controllers
{
    public class PersonsController : Controller
    {
        [Route("persons/index")]
        [Route("/")]
        public IActionResult Index()
        {
            return View();
        }
    }
}
