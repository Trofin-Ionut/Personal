﻿using Microsoft.AspNetCore.Mvc;
using Services;
using ServiceContracts;
using ServiceContracts.DTO;
using ServiceContracts.Enums;

namespace Contacts_manager.Controllers
{
    public class PersonsController : Controller
    {
        private readonly IPersonService _personService;
        private readonly ICountriesService _countriesService;

        public PersonsController(IPersonService personService, ICountriesService countriesService)
        {
            _personService = personService;
            _countriesService = countriesService;
        }

        [Route("persons/index")]
        [Route("/")]
        public IActionResult Index(string? searchString,string searchBy,string sortBy=nameof(PersonResponse.PersonName),SortOrderOptions order=SortOrderOptions.ASC)
        {
            ViewBag.SearchFields=new Dictionary<string, string>()
            {
                {nameof(PersonResponse.PersonName),"Person name" },
                {nameof(PersonResponse.Email),"Email" },
                {nameof(PersonResponse.DateOfBirth),"Date of Birth" },
                {nameof(PersonResponse.Gender),"Gender" },
                {nameof(PersonResponse.CountryId),"Country" },
                {nameof(PersonResponse.Address),"Address" },
            };
            List<PersonResponse>? response = _personService.GetFilteredPerson(searchBy,searchString);
            ViewBag.CurrentSearchBy = searchBy;
            ViewBag.CurrentSearchString = searchString;

            List<PersonResponse> sortedPeople = _personService.GetSortedPersons(response, sortBy, order);

            return View(response);
        }
        //Executes when "Create person" hyperlink is clicked
        [Route("persons/create")]
        [HttpGet]
        public IActionResult Create()
        {
            List<CountryResponse> countries = _countriesService.GetAllCountries();
            ViewBag.Countries = countries;
            return View();
        }
    }
}
