﻿using Microsoft.AspNetCore.Mvc;
using Configuration.Models;
using Microsoft.Extensions.Options;

namespace Configuration.Controllers
{
    public class HomeController : Controller
    {
        //private readonly IConfiguration _configuration;
        private readonly MasterOptions _configuration;

        public HomeController(IOptions<MasterOptions> configuration)
        {
            _configuration = configuration.Value;
        }
        /*
        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration.Value;
        }
        */
        [Route("/")]
        public IActionResult Index()
        {
            //ViewBag.MyKey = _configuration["MyKey"];
            //ViewBag.smtKey = _configuration.GetValue("smtKey", "default smt key");

            //hierarchical configuration
            //ViewBag.MyKey = _configuration["MyMasterKey:key1"];
            //ViewBag.smtKey = _configuration.GetValue("MyMasterKey:key2", "default key2 stuff ");

            //method 2:
            /*IConfigurationSection master = _configuration.GetSection("MyMasterKey");
            ViewBag.MyKey = master["key1"];
            ViewBag.smtKey = master["key2"];
            */
            //sau scrii asa : Nota: Cand fol. Get=> creezi obiect nou cu datele la care se poate face binding din appsetting.json
            //MasterOptions master = _configuration.GetSection("MyMasterKey").Get<MasterOptions>();

            //sau asa: Nota: Bind-ul ataseaza datele la un obiect deja creat, fata de Get... care iti creeaza un obiect pentru a-i face binding
            /*MasterOptions master = new(); 
            _configuration.GetSection("MyMasterKey").Bind(master);
            ViewBag.MyKey = master.Key1;
            ViewBag.smtKey=master.Key2;
            */

            //pentru metoda cu configurare ca serviciu:
            ViewBag.MyKey = _configuration.Key1;
            ViewBag.smtKey=_configuration.Key2;
            return View();
        }
    }
}
