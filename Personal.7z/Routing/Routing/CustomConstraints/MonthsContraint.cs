﻿using System.Text.RegularExpressions;

namespace Routing.CustomConstraints
{
    public class MonthsContraint : IRouteConstraint
    {
        public bool Match(HttpContext? httpContext, IRouter? route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
        {
            Regex match = new Regex($"^(apr|jul|oct|jan)$");
            string month= Convert.ToString(values[routeKey]);
            if(!values.ContainsKey(routeKey)) 
            {
                return false;
            }
            return (match.IsMatch(month));
        }
    }
}
