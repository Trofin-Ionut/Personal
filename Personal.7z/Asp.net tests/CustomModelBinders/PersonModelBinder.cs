﻿using Asp.net_tests.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Asp.net_tests.CustomModelBinders
{
    public class PersonModelBinder : IModelBinder
    {
        public Task BindModelAsync(ModelBindingContext bindingContext)
        {
            Person person = new();
            if(bindingContext.ValueProvider.GetValue("FirstName").Count() > 0)
            {
                person.Name = bindingContext.ValueProvider.GetValue("FirstName").FirstValue+" ";
            }
            if (bindingContext.ValueProvider.GetValue("LastName").Count() > 0)
            {
                person.Name += bindingContext.ValueProvider.GetValue("LastName").FirstValue;
               // bindingContext.Result = ModelBindingResult.Success(person); //this is the actual result
               // return Task.CompletedTask;
            }
            if (bindingContext.ValueProvider.GetValue("Email").Count() > 0)
            {
                person.Name = bindingContext.ValueProvider.GetValue("Email").FirstValue;
            }
            if (bindingContext.ValueProvider.GetValue("Phone").Count() > 0)
            {
                person.Name = bindingContext.ValueProvider.GetValue("Phone").FirstValue;
            }
            if (bindingContext.ValueProvider.GetValue("Password").Count() > 0)
            {
                person.Name = bindingContext.ValueProvider.GetValue("Password").FirstValue;
            }
            if (bindingContext.ValueProvider.GetValue("ConfirmPassword").Count() > 0)
            {
                person.Name = bindingContext.ValueProvider.GetValue("ConfirmPassword").FirstValue;
            }
            return null;
        }
    }
}
