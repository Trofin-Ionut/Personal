﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using Asp.net_tests.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;

namespace Asp.net_tests.CustomModelBinders
{
    public class PersonBinderProvider : IModelBinderProvider
    {
        public IModelBinder? GetBinder(ModelBinderProviderContext context)
        {
            //this works for default binders aswell (they can help you skip their tags)
            if(context.Metadata.ModelType==typeof(Person))
            {
                return new BinderTypeModelBinder(typeof(PersonModelBinder));
            }
            return null;
        }
    }
}
