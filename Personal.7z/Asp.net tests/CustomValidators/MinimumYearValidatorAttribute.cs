﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace Asp.net_tests.CustomValidators
{
    public class MinimumYearValidatorAttribute : ValidationAttribute
    {
        public int MinimumYear { get; set; } = 2000;
        public string DefaultErrorMessage = "Year can't be smaller than";
        public  MinimumYearValidatorAttribute()
        {

        }
        public MinimumYearValidatorAttribute(int minimumYear)
        {
            MinimumYear = minimumYear;
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value != null)
            {
                DateTime data = (DateTime)value;
                if(data.Year <=2000)
                {
                    return new ValidationResult("Minimum year allowed is {0}");
                }
                return ValidationResult.Success;
            }
            return null;
        }
    }
}
