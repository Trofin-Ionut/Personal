﻿namespace Partial_Views.Models
{
    public class ListModel
    {
        public string ListTitle { get; set; }
        public List<string> ListItems { get; set; }
        public ListModel(string title,List<string> items) 
        {
            ListTitle = title;
            ListItems = items;
        }
    }
}
