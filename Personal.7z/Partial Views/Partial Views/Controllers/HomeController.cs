﻿using Microsoft.AspNetCore.Mvc;
using Partial_Views.Models;

namespace Partial_Views.Controllers
{
    public class HomeController : Controller
    {
        [Route("/")]
        public IActionResult Index()
        {
            ListModel model = new ListModel("Cities", new List<string>() { "Paris", "Romania", "China", "Japan", "Sweden" });
            return View(model);
        }
        [Route("About")]
        public IActionResult About()
        {
            return View();
        }
        [Route("stuff")]
        public IActionResult Stuff() 
        {
            ListModel model = new ListModel("Everything", new List<string>() { "glue", "cool", "monitor", "pages" });
            return PartialView("_ListPartialView", model);
        }
    }
}
