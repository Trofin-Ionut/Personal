﻿using Microsoft.AspNetCore.Mvc;

namespace Razor_Views__MVC_.Controllers
{
    public class ProductsController : Controller
    {
        [Route("products")]
        public IActionResult All() //for shared folder purposes
        {
            return View();
        }
    }
}
