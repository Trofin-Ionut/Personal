﻿namespace Razor_Views__MVC_.Models
{
    public class PersonAndProductWrapperModel
    {
        public Person person { get; set; }
        public Product product { get; set; }
    }
}
